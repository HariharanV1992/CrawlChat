"""
Core application components.
""" 