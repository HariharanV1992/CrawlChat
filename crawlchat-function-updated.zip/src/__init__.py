"""
Stock Market Crawler - Main Source Package
"""

__version__ = "2.0.0"
__author__ = "Stock Market Crawler Team" 