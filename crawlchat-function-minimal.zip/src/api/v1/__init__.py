"""
API v1 endpoints for Stock Market Crawler.
""" 