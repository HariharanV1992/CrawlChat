"""
API layer for Stock Market Crawler.
""" 