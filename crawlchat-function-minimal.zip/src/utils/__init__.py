"""
Utility functions for Stock Market Crawler.
""" 