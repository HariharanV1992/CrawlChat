"""
Business logic services for Stock Market Crawler.
""" 